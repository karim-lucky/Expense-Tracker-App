"use client";
// import MyExpensiveTracerExpensiveTracer from '@/component/my-project'; // Ensure the path is correct
import MyExpensiveTracer from "@/component/my-project/expensiveTracer";

export default function Page() {
  return <div>
    <MyExpensiveTracer></MyExpensiveTracer>
  </div>;
}
